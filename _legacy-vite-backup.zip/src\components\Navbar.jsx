import React, { useState } from 'react'
import { Menu, X } from 'lucide-react'

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="w-full pt-8 pb-4 relative z-50">
      <div className="fluid-container">
        <div className="flex items-center justify-between">
          
          {/* Left Brand - Pure Clean Monospace with Wide Tracking */}
          <a href="#hero" className="font-mono text-xs sm:text-sm md:text-base font-bold tracking-[0.35em] uppercase text-white hover:text-silver-200 transition-colors">
            CYBERMES OFFSEC
          </a>

          {/* Desktop Right Navigation */}
          <div className="hidden md:flex items-center gap-3">
            {/* Border-separated links container */}
            <div className="flex items-center rounded-lg bg-white/[0.04] border border-white/10 overflow-hidden">
              <a 
                href="#features" 
                className="px-5 py-2.5 font-mono text-[11px] uppercase tracking-[0.25em] text-silver-300 hover:text-white hover:bg-white/[0.06] transition-colors"
              >
                FEATURES
              </a>
              <div className="w-px h-4 bg-white/10" />
              <a 
                href="#value" 
                className="px-5 py-2.5 font-mono text-[11px] uppercase tracking-[0.25em] text-silver-300 hover:text-white hover:bg-white/[0.06] transition-colors"
              >
                VALUE
              </a>
              <div className="w-px h-4 bg-white/10" />
              <a 
                href="#testimonials" 
                className="px-5 py-2.5 font-mono text-[11px] uppercase tracking-[0.25em] text-silver-300 hover:text-white hover:bg-white/[0.06] transition-colors"
              >
                TESTIMONIALS
              </a>
            </div>

            {/* Solid White / Silver Button */}
            <a 
              href="#beta" 
              className="px-6 py-2.5 rounded-lg bg-white text-black font-mono text-[11px] font-bold tracking-[0.25em] uppercase hover:bg-silver-200 transition-all shadow-md flex items-center justify-center cursor-pointer"
            >
              JOIN BETA
            </a>
          </div>

          {/* Mobile Hamburger */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-silver-300 hover:text-white rounded-lg bg-white/5 border border-white/10"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

        </div>

        {/* Mobile Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-3 p-4 rounded-xl frosted-glass border border-white/15 flex flex-col gap-2">
            <a 
              href="#features" 
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2.5 font-mono text-xs uppercase tracking-widest text-silver-300 hover:text-white rounded-lg hover:bg-white/5"
            >
              FEATURES
            </a>
            <a 
              href="#value" 
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2.5 font-mono text-xs uppercase tracking-widest text-silver-300 hover:text-white rounded-lg hover:bg-white/5"
            >
              VALUE
            </a>
            <a 
              href="#testimonials" 
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2.5 font-mono text-xs uppercase tracking-widest text-silver-300 hover:text-white rounded-lg hover:bg-white/5"
            >
              TESTIMONIALS
            </a>
            <a 
              href="#beta" 
              onClick={() => setMobileMenuOpen(false)}
              className="mt-2 py-3 text-center rounded-lg bg-white text-black font-mono text-xs font-bold tracking-widest uppercase"
            >
              JOIN BETA
            </a>
          </div>
        )}
      </div>
    </header>
  )
}

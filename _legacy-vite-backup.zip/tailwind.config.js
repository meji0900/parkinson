/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        obsidian: {
          DEFAULT: '#080808',
          deep: '#040404',
          surface: '#0d0d0d',
          card: '#121212',
          border: 'rgba(255, 255, 255, 0.08)',
          'border-bright': 'rgba(255, 255, 255, 0.20)',
          'border-focus': 'rgba(255, 255, 255, 0.35)',
        },
        silver: {
          50: '#F8FAFC',
          100: '#F1F5F9',
          200: '#E2E8F0',
          300: '#CBD5E1',
          400: '#94A3B8',
          500: '#64748B',
          600: '#475569',
          700: '#334155',
          800: '#1E293B',
          900: '#0F172A',
        }
      },
      fontFamily: {
        serif: ['"DM Serif Display"', 'Georgia', 'serif'],
        mono: ['"Geist Mono"', '"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Monaco', 'Consolas', 'monospace'],
        sans: ['"Inter"', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', 'sans-serif'],
      },
      borderRadius: {
        'hero': '4rem',
        'hero-mobile': '2rem',
        'card': '1rem',
        'bento': '1.25rem',
      },
      transitionTimingFunction: {
        'cyber': 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
      letterSpacing: {
        'widest-tech': '0.35em',
        'ultra-tech': '0.5em',
      },
      backgroundImage: {
        'silver-gradient': 'linear-gradient(135deg, #F8FAFC 0%, #94A3B8 100%)',
        'silver-glow': 'radial-gradient(circle at 50% 0%, rgba(255, 255, 255, 0.12) 0%, rgba(8, 8, 8, 0) 75%)',
        'card-gradient': 'linear-gradient(180deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.005) 100%)',
      }
    },
  },
  plugins: [],
}

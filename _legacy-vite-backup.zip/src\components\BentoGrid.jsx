import React from 'react'
import { Filter, Cpu, CheckCircle, Database, Zap, Code2, ArrowUpRight } from 'lucide-react'
import MemberRegistryCard from './MemberRegistryCard'

export default function BentoGrid() {
  return (
    <section id="features" className="py-20 md:py-28 relative">
      <div className="fluid-container">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 md:mb-16 border-b border-white/10 pb-8">
          <div>
            <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-silver-500 mb-2">
              <span>02</span>
              <span>// CAPABILITY MATRIX</span>
            </div>
            <h2 className="font-serif italic text-4xl sm:text-5xl md:text-6xl text-white">
              Engineered for Precision. <br />
              <span className="silver-gradient-text">Architected for Speed.</span>
            </h2>
          </div>
          <p className="font-mono text-xs md:text-sm text-silver-400 max-w-md mt-4 md:mt-0 uppercase tracking-wide">
            Replacing brittle bash scripts and noisy LLM loops with a deterministic Go-powered offensive infrastructure.
          </p>
        </div>

        {/* 4-Column Technical Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Card 01: Stream Filter */}
          <div className="bento-card relative rounded-2xl p-6 flex flex-col justify-between overflow-hidden group">
            <div>
              <div className="flex items-center justify-between mb-6">
                <span className="font-mono text-[10px] uppercase tracking-widest text-silver-500">
                  01 / EFFICIENCY
                </span>
                <Filter className="w-4 h-4 text-silver-400 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-serif italic text-2xl lg:text-3xl text-white mb-3">
                smart_pipe Token Filter
              </h3>
              <p className="font-mono text-[11px] text-silver-400 uppercase tracking-wider leading-relaxed mb-6">
                HIGH-SPEED STREAM PARSER THAT ARCHIVES RAW 404/STATIC LOGS TO DISK WHILE EMITTING ONLY HIGH-SIGNAL ATTACK PATHS TO THE AI CONTEXT.
              </p>
            </div>

            <div className="bg-obsidian-deep p-3 rounded-xl border border-white/5 font-mono text-[10px] text-silver-300">
              <div className="text-silver-500 mb-1">$ katana | smart_pipe --target auth0</div>
              <div className="text-white flex items-center justify-between">
                <span>REDUCED CONTEXT NOISE:</span>
                <span className="font-bold text-white">-88.4%</span>
              </div>
            </div>
          </div>

          {/* Card 02: Native Go MCP */}
          <div className="bento-card relative rounded-2xl p-6 flex flex-col justify-between overflow-hidden group">
            <div>
              <div className="flex items-center justify-between mb-6">
                <span className="font-mono text-[10px] uppercase tracking-widest text-silver-500">
                  02 / PROTOCOL
                </span>
                <Cpu className="w-4 h-4 text-silver-400 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-serif italic text-2xl lg:text-3xl text-white mb-3">
                Native Go MCP Engine
              </h3>
              <p className="font-mono text-[11px] text-silver-400 uppercase tracking-wider leading-relaxed mb-6">
                UNIVERSAL JSON-RPC 2.0 SERVER EXPOSING 10+ COMPILED SECURITY UTILITIES AND 200+ PLAYBOOKS TO ANY AI CODING ASSISTANT.
              </p>
            </div>

            <div className="bg-obsidian-deep p-3 rounded-xl border border-white/5 font-mono text-[10px] text-silver-300">
              <div className="text-silver-500 mb-1">$ npx -y cybermes-mcp install</div>
              <div className="text-white flex items-center justify-between">
                <span>CLIENTS:</span>
                <span className="font-bold text-white">GEMINI / CURSOR / CLAUDE</span>
              </div>
            </div>
          </div>

          {/* Card 03: Deterministic PoC Gate */}
          <div className="bento-card relative rounded-2xl p-6 flex flex-col justify-between overflow-hidden group">
            <div>
              <div className="flex items-center justify-between mb-6">
                <span className="font-mono text-[10px] uppercase tracking-widest text-silver-500">
                  03 / VERIFICATION
                </span>
                <CheckCircle className="w-4 h-4 text-silver-400 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-serif italic text-2xl lg:text-3xl text-white mb-3">
                Zero-False-Positive Gate
              </h3>
              <p className="font-mono text-[11px] text-silver-400 uppercase tracking-wider leading-relaxed mb-6">
                STRICT ANTI-HALLUCINATION ENFORCEMENT. NO VULNERABILITY IS RECORDED WITHOUT STANDALONE PYTHON POC SCRIPTS AND RAW HTTP PROOFS.
              </p>
            </div>

            <div className="bg-obsidian-deep p-3 rounded-xl border border-white/5 font-mono text-[10px] text-silver-300">
              <div className="text-silver-500 mb-1">OUTPUT: reports/&lt;slug&gt;/pocs/</div>
              <div className="text-white flex items-center justify-between">
                <span>REPRODUCIBILITY:</span>
                <span className="font-bold text-white">100% REPLAYABLE</span>
              </div>
            </div>
          </div>

          {/* Card 04: Member Registry */}
          <MemberRegistryCard />

        </div>
      </div>
    </section>
  )
}

import React from 'react'
import { Shield, Terminal, Github, ArrowUpRight, Lock, Radio } from 'lucide-react'
import BetaForm from './BetaForm'

export default function Footer() {
  return (
    <footer className="pt-20 pb-28 md:pb-16 border-t border-white/10 bg-[#060606] relative">
      <div className="fluid-container">
        
        {/* Final CTA Card */}
        <div className="frosted-glass rounded-[2rem] md:rounded-3xl p-8 sm:p-12 md:p-16 border border-white/15 text-center mb-20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-white/[0.03] to-transparent pointer-events-none" />
          
          <div className="relative z-10 max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.04] border border-white/10 mb-6">
              <Radio className="w-3.5 h-3.5 text-white animate-pulse" />
              <span className="font-mono text-[10px] uppercase tracking-widest text-silver-300">
                OPERATIONAL DEPLOYMENT READY
              </span>
            </div>

            <h2 className="font-serif italic text-4xl sm:text-6xl md:text-7xl text-white mb-6 leading-tight">
              Begin Autonomous Surface Execution.
            </h2>

            <p className="font-sans font-light text-silver-300 text-sm md:text-lg mb-10">
              Integrate with your AI IDE in 30 seconds via Model Context Protocol or run the native Go CLI in continuous CI/CD pipelines.
            </p>

            <BetaForm />
          </div>
        </div>

        {/* System Telemetry & Matrix Bar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 py-10 border-b border-white/10 font-mono text-xs">
          
          {/* Col 1: Identity */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-white" />
              <span className="font-bold text-white tracking-widest uppercase">
                CYBERMES // 0xOFFSEC
              </span>
            </div>
            <p className="font-sans text-xs text-silver-500 font-light leading-relaxed">
              Autonomous Offensive Security & Bug Bounty Automation Framework for authorized researchers.
            </p>
          </div>

          {/* Col 2: Specifications */}
          <div className="space-y-2 text-silver-400">
            <div className="text-white uppercase tracking-widest font-bold text-[10px]">
              SPECIFICATION
            </div>
            <div>CORE: <span className="text-white">GO 1.22+ NATIVE</span></div>
            <div>PROTOCOL: <span className="text-white">MCP JSON-RPC 2.0</span></div>
            <div>VERIFICATION: <span className="text-white">DETERMINISTIC POC</span></div>
          </div>

          {/* Col 3: Community & Source */}
          <div className="space-y-2 text-silver-400">
            <div className="text-white uppercase tracking-widest font-bold text-[10px]">
              DEVELOPER ACCESS
            </div>
            <div>
              <a 
                href="https://github.com/wutheringweather/Charon" 
                target="_blank" 
                rel="noreferrer"
                className="hover:text-white flex items-center gap-1 transition-colors"
              >
                <span>GitHub Repository</span>
                <ArrowUpRight className="w-3 h-3 opacity-60" />
              </a>
            </div>
            <div>
              <a 
                href="https://github.com/wutheringweather/Charon/blob/main/docs/MCP_SETUP.md" 
                target="_blank" 
                rel="noreferrer"
                className="hover:text-white flex items-center gap-1 transition-colors"
              >
                <span>MCP Setup Guide</span>
                <ArrowUpRight className="w-3 h-3 opacity-60" />
              </a>
            </div>
            <div>
              <a 
                href="https://github.com/wutheringweather/Charon/blob/main/AGENTS.md" 
                target="_blank" 
                rel="noreferrer"
                className="hover:text-white flex items-center gap-1 transition-colors"
              >
                <span>Agent Directives (AGENTS.md)</span>
                <ArrowUpRight className="w-3 h-3 opacity-60" />
              </a>
            </div>
          </div>

          {/* Col 4: Telemetry Status */}
          <div className="space-y-2 font-mono text-silver-400">
            <div className="text-white uppercase tracking-widest font-bold text-[10px]">
              TELEMETRY & HEALTH
            </div>
            <div className="flex items-center gap-2 text-white">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
              <span>ALL SYSTEMS OPERATIONAL</span>
            </div>
            <div className="text-[10px] text-silver-500">
              BUILD REF: <span className="text-silver-400">v3.0.0-PROD-0x9F4</span>
            </div>
            <div className="text-[10px] text-silver-500">
              LICENSE: <span className="text-silver-400">APACHE 2.0 OPEN SPEC</span>
            </div>
          </div>

        </div>

        {/* Copyright & Disclaimer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between font-mono text-[10px] uppercase tracking-widest text-silver-500 gap-4 text-center sm:text-left">
          <div>
            © 2026 CYBERMES RESEARCH COLLECTIVE. STRICTLY FOR AUTHORIZED ENGAGEMENTS.
          </div>
          <div className="flex items-center gap-4">
            <span>NOISE: SVG FRACTAL 0.05</span>
            <span>•</span>
            <span>MODERN OBSIDIAN DESIGN SYSTEM</span>
          </div>
        </div>

      </div>
    </footer>
  )
}

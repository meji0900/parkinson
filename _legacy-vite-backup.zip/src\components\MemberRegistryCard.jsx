import React from 'react'
import { Users, Shield, Award, Terminal, ExternalLink } from 'lucide-react'

const members = [
  {
    name: 'wutheringweather',
    role: 'CORE ARCHITECT / LEAD',
    gh: 'https://github.com/wutheringweather',
    avatar: 'https://github.com/wutheringweather.png',
    status: 'ACTIVE_DEV'
  },
  {
    name: 'msarg44',
    role: 'PLAYBOOK & EXPLOIT DEV',
    gh: 'https://github.com/msarg44',
    avatar: 'https://github.com/msarg44.png',
    status: 'CONTRIBUTOR'
  },
  {
    name: 'Mortify4315',
    role: 'AUTOMATION & PIPELINE',
    gh: 'https://github.com/Mortify4315',
    avatar: 'https://github.com/Mortify4315.png',
    status: 'CONTRIBUTOR'
  },
  {
    name: 'xsoft',
    role: 'MCP PROTOCOL RESEARCH',
    gh: 'https://github.com/xsoft',
    avatar: 'https://github.com/xsoft.png',
    status: 'SECURITY_OPS'
  }
]

export default function MemberRegistryCard() {
  return (
    <div className="bento-card relative rounded-2xl p-6 flex flex-col justify-between overflow-hidden group">
      {/* Decorative Watermark in Bottom Right */}
      <div className="absolute -bottom-6 -right-6 text-white/[0.04] pointer-events-none group-hover:text-white/[0.07] transition-colors">
        <Shield className="w-36 h-36 stroke-[1]" />
      </div>

      {/* Top Header */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-silver-500">
            04 // RESEARCH SQUAD
          </span>
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-white/5 border border-white/10 font-mono text-[9px] text-silver-300">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            REGISTRY
          </div>
        </div>

        <h3 className="font-serif italic text-2xl lg:text-3xl text-white mb-2">
          Security Researchers & Maintainers
        </h3>
        <p className="font-mono text-[11px] text-silver-400 uppercase tracking-wider mb-6">
          Global offensive research collective maintaining 200+ specialized SOPs.
        </p>
      </div>

      {/* 2x2 Grid of Member Badges with Hover Interactions */}
      <div className="grid grid-cols-2 gap-3 relative z-10">
        {members.map((m, idx) => (
          <a
            key={idx}
            href={m.gh}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2.5 p-2 rounded-xl bg-white/[0.02] border border-white/5 hover:border-white/20 hover:bg-white/[0.06] transition-all duration-300 hover:translate-x-1 group/item"
          >
            <div className="relative flex-shrink-0">
              <img
                src={m.avatar}
                alt={m.name}
                className="w-8 h-8 rounded-lg grayscale contrast-125 object-cover border border-white/20 group-hover/item:scale-110 group-hover/item:grayscale-0 transition-all duration-300"
                onError={(e) => {
                  e.target.onerror = null
                  e.target.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" fill="%23222"/><text x="16" y="20" font-family="monospace" font-size="12" fill="%23fff" text-anchor="middle">OP</text></svg>'
                }}
              />
            </div>
            <div className="flex flex-col min-w-0 overflow-hidden">
              <span className="font-mono text-xs font-bold text-silver-200 group-hover/item:text-white truncate transition-colors">
                {m.name}
              </span>
              <span className="font-mono text-[8px] uppercase tracking-wider text-silver-500 group-hover/item:text-silver-300 truncate">
                {m.role}
              </span>
            </div>
          </a>
        ))}
      </div>

      {/* Bottom Status */}
      <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between font-mono text-[9px] text-silver-500 uppercase tracking-widest">
        <span>VERIFIED CONTRIBUTORS</span>
        <span className="text-white/60">APACHE 2.0 OPEN SPEC</span>
      </div>
    </div>
  )
}

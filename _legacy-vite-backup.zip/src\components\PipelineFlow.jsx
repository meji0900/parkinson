import React from 'react'
import { Brain, Search, Cpu, ShieldCheck, FileSpreadsheet, ArrowRight } from 'lucide-react'

const stages = [
  {
    step: '01',
    name: 'Hermes Reasoning',
    sub: 'Autonomous Decision Loop',
    desc: 'Autonomous multi-agent coordinator reasoning over target scope, parameter maps, and attack graphs via MCP.',
    icon: Brain
  },
  {
    step: '02',
    name: 'Active Reconnaissance',
    sub: 'Passive & Active Crawling',
    desc: 'Deep multi-vector asset discovery utilizing subfinder, httpx, katana, and gau at rate-controlled speeds.',
    icon: Search
  },
  {
    step: '03',
    name: 'Smart Analysis & SOPs',
    sub: 'Token-Optimized Stream Filter',
    desc: 'smart_pipe strips context exhaustion; 200+ offline playbooks match API, JWT, and cloud vulnerabilities.',
    icon: Cpu
  },
  {
    step: '04',
    name: 'Validation Gate',
    sub: 'Zero-False-Positive PoC',
    desc: 'Generates non-destructive standalone Python exploit scripts (pocs/poc_*.py) with raw HTTP request/response traces.',
    icon: ShieldCheck
  },
  {
    step: '05',
    name: 'Automated Reporting',
    sub: 'Multi-Format Deliverables',
    desc: 'Auto-compilation into SUMMARY.md, structured metadata.json, standalone HTML, and print-ready executive PDFs.',
    icon: FileSpreadsheet
  }
]

export default function PipelineFlow() {
  return (
    <section id="architecture" className="py-20 md:py-28 border-y border-white/10 bg-white/[0.004] relative">
      <div className="fluid-container">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.04] border border-white/10 mb-4">
            <span className="font-mono text-[10px] uppercase tracking-widest text-silver-300">
              01 // CLOSED-LOOP OPERATIONAL ARCHITECTURE
            </span>
          </div>
          <h2 className="font-serif italic text-4xl sm:text-5xl md:text-6xl text-white mb-4">
            The Autonomous Offensive Pipeline.
          </h2>
          <p className="font-sans font-light text-silver-300 text-sm md:text-base leading-relaxed">
            A deterministic five-stage feedback loop engineered to eliminate guesswork and deliver verified security findings.
          </p>
        </div>

        {/* 5-Step Pipeline Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 relative">
          {stages.map((st, i) => {
            const Icon = st.icon
            return (
              <div 
                key={i} 
                className="frosted-glass rounded-2xl p-6 border border-white/10 hover:border-white/25 hover:bg-white/[0.04] transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  {/* Step indicator */}
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-mono text-xs font-bold text-white bg-white/10 px-2 py-0.5 rounded border border-white/15">
                      STAGE {st.step}
                    </span>
                    <Icon className="w-5 h-5 text-silver-400 group-hover:text-white transition-colors" />
                  </div>

                  <h3 className="font-serif italic text-xl text-white mb-1">
                    {st.name}
                  </h3>
                  <div className="font-mono text-[9px] uppercase tracking-widest text-silver-500 mb-3">
                    {st.sub}
                  </div>
                  <p className="font-sans text-xs text-silver-400 font-light leading-relaxed">
                    {st.desc}
                  </p>
                </div>

                <div className="mt-6 pt-3 border-t border-white/5 flex items-center justify-between font-mono text-[9px] text-silver-500 uppercase">
                  <span>STATE: VERIFIED</span>
                  <ArrowRight className="w-3 h-3 opacity-40 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                </div>
              </div>
            )
          })}
        </div>

        {/* Architecture Pipeline Schema Banner */}
        <div className="mt-10 p-4 rounded-xl bg-obsidian-card border border-white/10 font-mono text-xs text-center text-silver-400 overflow-x-auto select-none">
          <span className="text-white font-semibold">[Hermes Reasoning]</span> 
          <span className="text-white/30 mx-2">──►</span> 
          <span className="text-white font-semibold">[Reconnaissance]</span> 
          <span className="text-white/30 mx-2">──►</span> 
          <span className="text-white font-semibold">[Analysis & Skills]</span> 
          <span className="text-white/30 mx-2">──►</span> 
          <span className="text-white font-semibold">[Validation Gate]</span> 
          <span className="text-white/30 mx-2">──►</span> 
          <span className="text-white font-semibold">[Structured Reporting]</span>
        </div>

      </div>
    </section>
  )
}

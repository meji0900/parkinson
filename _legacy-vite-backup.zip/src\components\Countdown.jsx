import React, { useState, useEffect } from 'react'
import { Activity, Clock } from 'lucide-react'

export default function Countdown() {
  const [timeLeft, setTimeLeft] = useState({
    days: '04',
    hours: '18',
    minutes: '42',
    seconds: '19',
    millis: '84'
  })

  useEffect(() => {
    // Set a target epoch 5 days ahead from now
    const target = new Date(Date.now() + (4 * 24 * 3600 + 18 * 3600 + 42 * 60) * 1000).getTime()

    const interval = setInterval(() => {
      const now = Date.now()
      const difference = target - now

      if (difference <= 0) {
        setTimeLeft({ days: '00', hours: '00', minutes: '00', seconds: '00', millis: '00' })
        return
      }

      const d = Math.floor(difference / (1000 * 60 * 60 * 24))
      const h = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const m = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))
      const s = Math.floor((difference % (1000 * 60)) / 1000)
      const ms = Math.floor((difference % 1000) / 10)

      setTimeLeft({
        days: String(d).padStart(2, '0'),
        hours: String(h).padStart(2, '0'),
        minutes: String(m).padStart(2, '0'),
        seconds: String(s).padStart(2, '0'),
        millis: String(ms).padStart(2, '0')
      })
    }, 47)

    return () => clearInterval(interval)
  }, [])

  return (
    <section className="py-16 md:py-24 border-y border-white/10 bg-white/[0.006] relative overflow-hidden">
      {/* Background Subtle Linear Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[300px] bg-white/[0.015] blur-3xl pointer-events-none rounded-full" />

      <div className="fluid-container relative z-10">
        <div className="flex flex-col items-center text-center">
          {/* Header Label */}
          <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-white/[0.03] border border-white/10 mb-6">
            <span className="w-2 h-2 rounded-full bg-white animate-ping" />
            <span className="font-mono text-[10px] md:text-xs uppercase tracking-widest-tech text-silver-300">
              NEXT PROTOCOL EPOCH // CYBERMES v3.1 SYNCHRONIZATION
            </span>
          </div>

          <p className="font-serif italic text-2xl md:text-3xl text-silver-300 max-w-xl mb-8">
            Deterministic zero-day intelligence feed & automated exploit verification window.
          </p>

          {/* Countdown Display */}
          <div className="flex flex-wrap items-center justify-center gap-3 md:gap-8 select-none">
            {/* Days */}
            <div className="flex flex-col items-center">
              <span className="font-mono text-[9px] md:text-[11px] uppercase tracking-ultra-tech text-silver-500 mb-1">
                DAYS
              </span>
              <span className="font-serif italic text-5xl sm:text-7xl md:text-8xl lg:text-[110px] text-white/90 leading-none tracking-tighter">
                {timeLeft.days}
              </span>
            </div>

            <span className="font-serif text-4xl sm:text-6xl md:text-8xl text-white/10 self-center -mt-2">/</span>

            {/* Hours */}
            <div className="flex flex-col items-center">
              <span className="font-mono text-[9px] md:text-[11px] uppercase tracking-ultra-tech text-silver-500 mb-1">
                HOURS
              </span>
              <span className="font-serif italic text-5xl sm:text-7xl md:text-8xl lg:text-[110px] text-white/90 leading-none tracking-tighter">
                {timeLeft.hours}
              </span>
            </div>

            <span className="font-serif text-4xl sm:text-6xl md:text-8xl text-white/10 self-center -mt-2">/</span>

            {/* Minutes */}
            <div className="flex flex-col items-center">
              <span className="font-mono text-[9px] md:text-[11px] uppercase tracking-ultra-tech text-silver-500 mb-1">
                MINUTES
              </span>
              <span className="font-serif italic text-5xl sm:text-7xl md:text-8xl lg:text-[110px] text-white/90 leading-none tracking-tighter">
                {timeLeft.minutes}
              </span>
            </div>

            <span className="font-serif text-4xl sm:text-6xl md:text-8xl text-white/10 self-center -mt-2">/</span>

            {/* Seconds */}
            <div className="flex flex-col items-center">
              <span className="font-mono text-[9px] md:text-[11px] uppercase tracking-ultra-tech text-silver-500 mb-1">
                SECONDS
              </span>
              <span className="font-serif italic text-5xl sm:text-7xl md:text-8xl lg:text-[110px] text-white/90 leading-none tracking-tighter">
                {timeLeft.seconds}
              </span>
            </div>

            <span className="hidden sm:inline font-serif text-4xl sm:text-6xl md:text-8xl text-white/10 self-center -mt-2">/</span>

            {/* Milliseconds */}
            <div className="hidden sm:flex flex-col items-center">
              <span className="font-mono text-[9px] md:text-[11px] uppercase tracking-ultra-tech text-silver-500 mb-1">
                MILLIS
              </span>
              <span className="font-serif italic text-4xl sm:text-6xl md:text-7xl lg:text-[90px] text-silver-500/80 leading-none tracking-tighter">
                {timeLeft.millis}
              </span>
            </div>
          </div>

          {/* Bottom Telemetry Note */}
          <div className="mt-8 flex items-center gap-4 font-mono text-[10px] uppercase tracking-widest text-silver-500">
            <span className="flex items-center gap-1.5 text-silver-400">
              <Clock className="w-3.5 h-3.5" />
              GLOBAL SYNC: UTC 00:00:00
            </span>
            <span>•</span>
            <span>RATE-LIMIT: STRICT 5-10 REQ/S BYPASS SAFE</span>
          </div>
        </div>
      </div>
    </section>
  )
}

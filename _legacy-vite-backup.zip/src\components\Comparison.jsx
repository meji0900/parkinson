import React from 'react'
import { Check, X } from 'lucide-react'

const comparisons = [
  {
    feature: 'AI Assistant Integration',
    traditional: 'Manual terminal copy-paste or fragile bash wrappers',
    cybermes: 'Native Go MCP Server (JSON-RPC 2.0) directly embedded in Gemini, Cursor, Claude',
  },
  {
    feature: 'LLM Token & Context Noise',
    traditional: 'Thousands of lines of 404s and static assets flood & exhaust context',
    cybermes: 'smart_pipe Go filter streams only high-signal endpoints (-85% token cost)',
  },
  {
    feature: 'Vulnerability Validation',
    traditional: 'Speculative regex hits and hallucinated alerts',
    cybermes: 'Mandatory standalone Python PoC scripts (pocs/poc_*.py) with raw HTTP proofs',
  },
  {
    feature: 'Payload & SOP Retrieval',
    traditional: 'Slow manual searching across browser tabs, wikis, and repos',
    cybermes: 'Sub-50ms offline local query across 200+ SOPs (search_knowledge)',
  },
  {
    feature: 'Deliverables & Reporting',
    traditional: 'Scattered plaintext notes requiring hours of manual synthesis',
    cybermes: 'Automated generation of SUMMARY.md, metadata.json, HTML & PDF reports',
  }
]

export default function Comparison() {
  return (
    <section id="value" className="py-20 md:py-28 relative">
      <div className="fluid-container">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 border-b border-white/10 pb-8">
          <div>
            <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-silver-500 mb-2">
              <span>03</span>
              <span>// VALUE PROPOSITION</span>
            </div>
            <h2 className="font-serif italic text-4xl sm:text-5xl md:text-6xl text-white">
              Why Cybermes Outperforms <br />
              <span className="silver-gradient-text">Legacy Toolchains.</span>
            </h2>
          </div>
          <p className="font-mono text-xs md:text-sm text-silver-400 max-w-sm mt-4 md:mt-0 uppercase tracking-wide">
            Engineered from first principles for modern AI-assisted offensive security research.
          </p>
        </div>

        {/* Matrix Table */}
        <div className="frosted-glass rounded-2xl md:rounded-3xl border border-white/15 overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 bg-white/[0.02]">
                  <th className="p-4 sm:p-6 font-mono text-xs uppercase tracking-widest text-silver-500 w-1/3">
                    DIMENSION / REQUIREMENT
                  </th>
                  <th className="p-4 sm:p-6 font-mono text-xs uppercase tracking-widest text-silver-600 w-1/3">
                    TRADITIONAL WRAPPERS
                  </th>
                  <th className="p-4 sm:p-6 font-mono text-xs uppercase tracking-widest text-white w-1/3 bg-white/[0.04] border-l border-white/10">
                    <span className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                      CYBERMES SYSTEM
                    </span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-sans text-xs sm:text-sm">
                {comparisons.map((item, idx) => (
                  <tr key={idx} className="hover:bg-white/[0.015] transition-colors">
                    <td className="p-4 sm:p-6 font-mono font-medium text-white text-xs sm:text-sm">
                      {item.feature}
                    </td>
                    <td className="p-4 sm:p-6 text-silver-500 font-light leading-relaxed">
                      <div className="flex items-start gap-2.5">
                        <X className="w-4 h-4 text-silver-600 flex-shrink-0 mt-0.5" />
                        <span>{item.traditional}</span>
                      </div>
                    </td>
                    <td className="p-4 sm:p-6 text-silver-100 font-medium leading-relaxed bg-white/[0.025] border-l border-white/10">
                      <div className="flex items-start gap-2.5">
                        <Check className="w-4 h-4 text-white flex-shrink-0 mt-0.5" />
                        <span>{item.cybermes}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </section>
  )
}

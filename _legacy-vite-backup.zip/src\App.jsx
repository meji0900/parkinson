import React, { useEffect } from 'react'
import Lenis from 'lenis'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Countdown from './components/Countdown'
import BentoGrid from './components/BentoGrid'
import Comparison from './components/Comparison'
import Testimonials from './components/Testimonials'
import Footer from './components/Footer'
import BottomNav from './components/BottomNav'

export default function App() {
  useEffect(() => {
    // Ultra-smooth momentum scroll with finely tuned lerp physics
    const lenis = new Lenis({
      lerp: 0.075,
      smoothWheel: true,
      syncTouch: true,
      syncTouchLerp: 0.075,
      wheelMultiplier: 0.85,
      touchMultiplier: 1.2,
      infinite: false,
    })

    function raf(time) {
      lenis.raf(time)
      requestAnimationFrame(raf)
    }

    const rafId = requestAnimationFrame(raf)

    // Butter-smooth anchor navigation handling
    const handleAnchorClick = (e) => {
      const anchor = e.target.closest('a[href^="#"]')
      if (anchor) {
        const targetId = anchor.getAttribute('href')
        if (targetId && targetId !== '#') {
          const targetEl = document.querySelector(targetId)
          if (targetEl) {
            e.preventDefault()
            lenis.scrollTo(targetEl, {
              offset: -30,
              duration: 1.6,
              easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
            })
          }
        }
      }
    }

    document.addEventListener('click', handleAnchorClick)

    return () => {
      cancelAnimationFrame(rafId)
      document.removeEventListener('click', handleAnchorClick)
      lenis.destroy()
    }
  }, [])

  return (
    <div className="relative min-h-screen bg-[#080808] text-[#E2E8F0] selection:bg-white selection:text-black">
      {/* SVG Fractal Noise Overlay (0.05 opacity) */}
      <div className="noise-overlay" aria-hidden="true" />

      {/* Global Navigation */}
      <Navbar />

      {/* Strict Vertical Narrative Flow per Prompt Specification */}
      <main className="relative z-10">
        {/* 1. Explosive Hero + Data Metadata + Capture Form */}
        <Hero />

        {/* 2. Urgency / Social Proof Countdown Timer */}
        <Countdown />

        {/* 3. Feature Bento Grid (including Member Registry Card) */}
        <BentoGrid />

        {/* 4. Value Proposition Matrix */}
        <Comparison />

        {/* 5. Testimonials */}
        <Testimonials />
      </main>

      {/* 6. Final CTA & Footer */}
      <Footer />

      {/* Special Component: Floating Mobile Bottom Nav */}
      <BottomNav />
    </div>
  )
}

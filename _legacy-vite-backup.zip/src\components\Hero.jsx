import React, { useEffect, useRef } from 'react'
import BetaForm from './BetaForm'

export default function Hero() {
  const leftHandRef = useRef(null)
  const rightHandRef = useRef(null)

  useEffect(() => {
    let animationFrameId

    const handleScroll = () => {
      animationFrameId = requestAnimationFrame(() => {
        const scrolled = window.scrollY
        if (scrolled < 1200) {
          // Calculate movement so the hands move gracefully towards each other with restrained proximity
          const offset = Math.min(scrolled, 550)
          
          // Left hand: moves gently down (+Y) and to the right (+X)
          if (leftHandRef.current) {
            leftHandRef.current.style.transform = `translate3d(${offset * 0.16}px, ${offset * 0.12}px, 0)`
          }
          
          // Right hand: moves gently up (-Y) and to the left (-X)
          if (rightHandRef.current) {
            rightHandRef.current.style.transform = `translate3d(${-offset * 0.16}px, ${-offset * 0.12}px, 0)`
          }
        }
      })
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => {
      window.removeEventListener('scroll', handleScroll)
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId)
      }
    }
  }, [])

  return (
    <section id="hero" className="pt-6 pb-16 md:pt-8 md:pb-24 relative overflow-hidden">
      <div className="fluid-container">
        
        {/* Main 4rem Radius Frosted Glass Hero Container */}
        <div className="relative frosted-glass rounded-hero-mobile md:rounded-hero px-6 py-16 sm:px-12 sm:py-20 md:px-16 md:py-28 border border-white/[0.08] shadow-2xl flex flex-col justify-between items-center text-center overflow-hidden">
          
          {/* Background Atmosphere (Black & White) */}
          <div className="absolute inset-0 z-0 pointer-events-none select-none">
            <div className="absolute top-0 left-0 w-full h-full opacity-50 mix-blend-screen">
              <img 
                src="https://framerusercontent.com/images/9zvwRJAavKKacVyhFCwHyXW1U.png?width=1536&height=1024" 
                alt="Atmosphere" 
                className="w-full h-full object-cover object-center grayscale contrast-125 opacity-70"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#080808]/50 to-[#080808]/95 z-10" />
          </div>

          {/* Floating Surrealist Elements with Scroll Parallax */}
          {/* Left Hand Parallax Container (Pushed further outward) */}
          <div 
            ref={leftHandRef}
            className="absolute -left-[20%] top-[-16%] md:-left-[12%] md:top-[-18%] lg:-left-[10%] lg:top-[-20%] w-[55vw] md:w-[38vw] max-w-[750px] z-10 pointer-events-none mix-blend-screen opacity-70 select-none will-change-transform"
          >
            <div className="animate-float-left w-full h-full">
              <img 
                src="https://framerusercontent.com/images/KNhiA5A2ykNYqNkj04Hk6BVg5A.png?width=1540&height=1320" 
                alt="Hand Reaching" 
                className="w-full h-auto object-contain grayscale contrast-125 brightness-90"
              />
            </div>
          </div>

          {/* Right Hand Parallax Container (Pushed further outward) */}
          <div 
            ref={rightHandRef}
            className="absolute -right-[20%] bottom-[-16%] md:-right-[12%] md:bottom-[-14%] lg:-right-[10%] lg:bottom-[-16%] w-[50vw] md:w-[34vw] max-w-[680px] z-10 pointer-events-none mix-blend-screen opacity-70 select-none will-change-transform"
          >
            <div className="animate-float-right w-full h-full">
              <img 
                src="https://framerusercontent.com/images/X89VFCABCEjjZ4oLGa3PjbOmsA.png?width=1542&height=1002" 
                alt="Hand Receiving" 
                className="w-full h-auto object-contain grayscale contrast-125 brightness-90"
              />
            </div>
          </div>

          {/* Top Subtle Light Gradient Effect */}
          <div className="absolute inset-x-0 top-0 h-48 bg-gradient-to-b from-white/[0.02] to-transparent pointer-events-none rounded-t-hero z-10" />

          {/* Massive Serif Headline (matching reference image style) */}
          <div className="relative z-20 my-auto w-full">
            <h1 className="font-serif italic font-normal tracking-[-0.04em] text-[48px] sm:text-7xl md:text-8xl lg:text-[116px] xl:text-[132px] leading-[0.88] text-white select-none mb-14 sm:mb-20 md:mb-24">
              Stop Guessing.<br />
              <span className="silver-gradient-text">Start Exploiting.</span>
            </h1>

            {/* Fluid Three-Column Metadata Bar */}
            <div className="w-full grid grid-cols-1 md:grid-cols-3 items-center gap-6 md:gap-4 mb-12 sm:mb-16 select-none">
              {/* Left Column */}
              <div className="text-center md:text-left font-mono text-[11px] sm:text-xs uppercase tracking-[0.25em] text-silver-400 leading-relaxed">
                <div>EST. 2026</div>
                <div>BETA ACCESS</div>
              </div>

              {/* Middle Column (Serif Italic) */}
              <div className="font-serif italic text-sm sm:text-base md:text-lg text-silver-300 max-w-lg mx-auto text-center leading-snug">
                The offensive intelligence engine for autonomous research. Create production-ready exploits 10x faster.
              </div>

              {/* Right Column */}
              <div className="text-center md:text-right font-mono text-[11px] sm:text-xs uppercase tracking-[0.25em] text-silver-400 leading-relaxed">
                <div>LIMITED SPOTS</div>
                <div>REMOTE/GLOBAL</div>
              </div>
            </div>

            {/* Beta Capture Form */}
            <div className="w-full">
              <BetaForm />
            </div>
          </div>

        </div>

      </div>
    </section>
  )
}



import React, { useState } from 'react'
import { Terminal, Copy, Check, Play, ShieldAlert, Cpu, FileText, CheckCircle2 } from 'lucide-react'

const demos = [
  {
    id: 'recon',
    name: '01 // SMART_PIPE RECON',
    cmd: 'katana -u https://api.target.internal -silent | smart_pipe --target target_internal --tool katana',
    output: [
      '[+] Initializing Cybermes SmartPipe stream filter [Go 1.22 Native]',
      '[*] Stream target slug: target_internal',
      '[*] Raw log capture: recon/target_internal/katana_raw.txt',
      '[-] Filtered 1,842 static assets & unauthenticated 404 redirects (Saved ~38,400 context tokens)',
      '[!] HIGH SIGNAL ENDPOINT: POST /api/v2/auth/refresh (JWT RS256 / Expose Bearer)',
      '[!] HIGH SIGNAL ENDPOINT: GET /api/v1/users/{id}/export_billing (IDOR candidate)',
      '[!] HIGH SIGNAL ENDPOINT: POST /graphql (Introspection Enabled: 42 Types Discovered)',
      '[✓] Recon streaming completed in 1.42s. 3 high-probability hypotheses queued for validation.'
    ]
  },
  {
    id: 'knowledge',
    name: '02 // OFFLINE INTEL (50ms)',
    cmd: 'search_knowledge "jwt algorithm confusion public key rsa to hmac"',
    output: [
      '[+] Query: "jwt algorithm confusion public key rsa to hmac" (Indexed: 200+ SOPs & HackTricks)',
      '[FOUND] skills/jwt_security/sop_algorithm_confusion.md (Score: 0.98)',
      '   ├── Attack Vector: Convert RS256 public key (PEM) into HMAC-SHA256 verification secret',
      '   ├── Bypass Payload: pyjwt.encode(claims, pub_key_bytes, algorithm="HS256")',
      '   └── Validation Gate: Assert status code 200 and differential response header X-Role: Admin',
      '[✓] Retrieved in 22ms. Injected into Hermes autonomous reasoning buffer.'
    ]
  },
  {
    id: 'poc',
    name: '03 // DETERMINISTIC POC',
    cmd: 'python reports/target_internal/pocs/poc_idor_billing.py',
    output: [
      '[*] Cybermes Deterministic PoC Gate [Safe Rate-Controlled: 5 req/s]',
      '[*] Target: https://api.target.internal/api/v1/users/10492/export_billing',
      '[*] Baseline: User 10491 (Session A) -> 200 OK (Content-Length: 1420)',
      '[*] Testing Unauthorized Ingestion: User 10492 via Session A token...',
      '[+] RAW HTTP EVIDENCE LOGGED: evidence/idor_billing_proof.json',
      '[+] Response: HTTP/2.0 200 OK | Body contains "invoice_id": "INV-9921", "card_last4": "4242"',
      '[CRITICAL CONFIRMED] IDOR in billing export. Zero-false-positive criteria met.',
      '[✓] Summary written to reports/target_internal/findings/critical_idor_billing.md'
    ]
  },
  {
    id: 'mcp',
    name: '04 // MCP AI AGENT CALL',
    cmd: 'npx -y cybermes-mcp install --gemini --cursor',
    output: [
      '[+] Cybermes Model Context Protocol (MCP) Server Setup',
      '[*] Detected clients: Google Antigravity / Gemini, Cursor IDE, Claude Code',
      '[*] Registering 10+ native security tool providers into MCP manifest...',
      '    ├── cybermes_smart_pipe (Stream filter)',
      '    ├── cybermes_secret_scan (48-pattern credential scanner)',
      '    ├── cybermes_search_knowledge (Instant offline intelligence)',
      '    └── cybermes_aggregate_reports (Report compiler)',
      '[✓] Successfully bound. Your AI assistant now wields autonomous offensive capabilities.'
    ]
  }
]

export default function TerminalPreview() {
  const [activeTab, setActiveTab] = useState(0)
  const [copied, setCopied] = useState(false)

  const activeDemo = demos[activeTab]

  const handleCopy = () => {
    navigator.clipboard.writeText(activeDemo.cmd)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <section id="terminal" className="py-20 md:py-28 relative">
      <div className="fluid-container">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.04] border border-white/10 mb-4">
            <Terminal className="w-3.5 h-3.5 text-silver-300" />
            <span className="font-mono text-[10px] uppercase tracking-widest text-silver-300">
              03 // REPRODUCIBLE OFFENSIVE PIPELINE
            </span>
          </div>
          <h2 className="font-serif italic text-4xl sm:text-5xl md:text-6xl text-white mb-4">
            Deterministic Validation in Real Time.
          </h2>
          <p className="font-sans font-light text-silver-300 text-sm md:text-base leading-relaxed">
            Experience how Cybermes cuts through context exhaustion, mines attack surfaces, and logs reproducible zero-false-positive proofs.
          </p>
        </div>

        {/* Terminal Container */}
        <div className="frosted-glass rounded-2xl md:rounded-3xl border border-white/15 overflow-hidden shadow-2xl bg-[#090909]">
          
          {/* Top Bar with Command Selector Tabs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between border-b border-white/10 bg-white/[0.02] px-4 py-2.5 gap-2">
            
            {/* macOS Dots & Status */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
              </div>
              <span className="font-mono text-[10px] uppercase tracking-widest text-silver-500 ml-2 hidden sm:inline">
                cybermes-shell // session_0x9A
              </span>
            </div>

            {/* Tab Switches */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              {demos.map((d, index) => (
                <button
                  key={d.id}
                  onClick={() => setActiveTab(index)}
                  className={`px-3 py-1.5 rounded-lg font-mono text-[10px] uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                    activeTab === index
                      ? 'bg-white text-black font-bold shadow-md'
                      : 'text-silver-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {d.name}
                </button>
              ))}
            </div>

            {/* Copy Command Button */}
            <button
              onClick={handleCopy}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-md bg-white/5 hover:bg-white/10 text-silver-300 hover:text-white font-mono text-[10px] transition-colors border border-white/5 cursor-pointer"
            >
              {copied ? <Check className="w-3 h-3 text-white" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'COPIED' : 'COPY'}</span>
            </button>
          </div>

          {/* Terminal Body */}
          <div className="p-6 md:p-8 font-mono text-xs md:text-sm text-silver-300 leading-relaxed overflow-x-auto min-h-[320px] flex flex-col justify-between">
            
            {/* Command Prompt */}
            <div>
              <div className="flex items-center gap-2 text-silver-400 mb-6 pb-4 border-b border-white/5">
                <span className="text-white font-bold select-none">operator@cybermes:~$</span>
                <span className="text-white font-medium">{activeDemo.cmd}</span>
              </div>

              {/* Output Lines */}
              <div className="space-y-2.5">
                {activeDemo.output.map((line, idx) => (
                  <div 
                    key={idx} 
                    className={`transition-all duration-300 ${
                      line.startsWith('[+]') || line.startsWith('[CRITICAL') 
                        ? 'text-white font-semibold' 
                        : line.startsWith('[!]')
                        ? 'text-silver-200'
                        : line.startsWith('[-] ')
                        ? 'text-silver-500'
                        : 'text-silver-400'
                    }`}
                  >
                    {line}
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Status Ticker */}
            <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] text-silver-500 uppercase tracking-widest">
              <span className="flex items-center gap-2 text-white">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                EXECUTION NOMINAL (EXIT CODE 0)
              </span>
              <span>BUFFER LATENCY: 14MS</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  )
}

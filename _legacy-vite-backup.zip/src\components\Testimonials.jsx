import React from 'react'

const testimonials = [
  {
    quote: "Cybermes eliminated 90% of the token hallucination in our automated bug bounty loops. The deterministic Python PoC generation makes report triage instantaneous.",
    author: "MARCUS VANCE",
    role: "PRINCIPAL SECURITY RESEARCHER // SYNACK RED TEAM",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
  },
  {
    quote: "Integrating cybermes-mcp into our AI IDE feels like equipping our research team with a high-speed Go security engine. The sub-50ms offline SOP retrieval is unmatched.",
    author: "ELENA ROSTOVA",
    role: "HEAD OF OFFENSIVE APIS // DEFCON SPEAKER",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
  }
]

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 md:py-32 bg-white/[0.01] border-y border-white/10 relative overflow-hidden">
      {/* Background Subtle Ambience */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[350px] bg-white/[0.015] blur-3xl pointer-events-none rounded-full" />

      <div className="fluid-container relative z-10">
        
        {/* Massive Centered Serif Italics Headline */}
        <div className="text-center max-w-4xl mx-auto mb-16 md:mb-24">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.04] border border-white/10 mb-4">
            <span className="font-mono text-[10px] uppercase tracking-widest text-silver-300">
              05 // PEER VERIFICATION & IMPACT
            </span>
          </div>
          <h2 className="font-serif italic text-4xl sm:text-6xl md:text-7xl lg:text-8xl text-white tracking-tight leading-[0.9]">
            The Standard in Deterministic Offensive Security.
          </h2>
        </div>

        {/* Two-Column Grid with Deep pl-16 Border-Left Accent */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {testimonials.map((t, idx) => (
            <div 
              key={idx} 
              className="relative pl-8 md:pl-16 border-l-2 border-white/20 hover:border-white/60 transition-colors flex flex-col justify-between"
            >
              {/* Quote Typography in Serif */}
              <blockquote className="font-serif italic text-2xl sm:text-3xl md:text-4xl text-silver-100 leading-snug mb-8">
                “{t.quote}”
              </blockquote>

              {/* Attribution with Grayscale Contrast-125 Avatar */}
              <div className="flex items-center gap-4">
                <img
                  src={t.avatar}
                  alt={t.author}
                  className="w-12 h-12 rounded-full grayscale contrast-125 object-cover border border-white/20"
                />
                <div className="flex flex-col">
                  <span className="font-mono text-sm font-bold tracking-widest uppercase text-white">
                    {t.author}
                  </span>
                  <span className="font-mono text-[10px] text-silver-500 uppercase tracking-widest mt-0.5">
                    {t.role}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  )
}

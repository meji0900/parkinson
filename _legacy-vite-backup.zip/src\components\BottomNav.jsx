import React, { useState, useEffect } from 'react'
import { Home, Layers, Sparkles, Sliders, MessageSquare } from 'lucide-react'

export default function BottomNav() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setVisible(true)
      } else {
        setVisible(false)
      }
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div
      className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-50 transition-all duration-700 pointer-events-auto ${
        visible
          ? 'translate-y-0 opacity-100'
          : 'translate-y-32 opacity-0 pointer-events-none'
      }`}
      style={{ transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)' }}
    >
      <nav className="flex items-center gap-1 p-1.5 px-3 rounded-full bg-[#080808]/85 backdrop-blur-2xl border border-white/15 shadow-[0_10px_35px_rgba(0,0,0,0.8)]">
        {/* Item 1: Home */}
        <a
          href="#hero"
          className="flex flex-col items-center justify-center p-2 px-3 rounded-full text-silver-400 hover:text-white transition-colors"
        >
          <Home className="w-4 h-4" />
          <span className="font-mono text-[8px] uppercase tracking-widest mt-0.5">HOME</span>
        </a>

        {/* Item 2: Features */}
        <a
          href="#features"
          className="flex flex-col items-center justify-center p-2 px-3 rounded-full text-silver-400 hover:text-white transition-colors"
        >
          <Layers className="w-4 h-4" />
          <span className="font-mono text-[8px] uppercase tracking-widest mt-0.5">BENTO</span>
        </a>

        {/* Middle Action: Solid White Button */}
        <a
          href="#beta"
          className="mx-1 px-5 py-2.5 rounded-full bg-white text-black font-mono text-[10px] font-bold tracking-widest uppercase hover:bg-silver-200 transition-all shadow-lg flex items-center gap-1.5"
        >
          <Sparkles className="w-3 h-3 fill-black" />
          <span>JOIN</span>
        </a>

        {/* Item 4: Value */}
        <a
          href="#value"
          className="flex flex-col items-center justify-center p-2 px-3 rounded-full text-silver-400 hover:text-white transition-colors"
        >
          <Sliders className="w-4 h-4" />
          <span className="font-mono text-[8px] uppercase tracking-widest mt-0.5">VALUE</span>
        </a>

        {/* Item 5: Testimonials */}
        <a
          href="#testimonials"
          className="flex flex-col items-center justify-center p-2 px-3 rounded-full text-silver-400 hover:text-white transition-colors"
        >
          <MessageSquare className="w-4 h-4" />
          <span className="font-mono text-[8px] uppercase tracking-widest mt-0.5">PROOFS</span>
        </a>
      </nav>
    </div>
  )
}

import React, { useState } from 'react'
import { ShieldCheck } from 'lucide-react'

export default function BetaForm() {
  const [inputVal, setInputVal] = useState('')
  const [status, setStatus] = useState('idle')
  const [tokenInfo, setTokenInfo] = useState(null)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!inputVal || !inputVal.includes('@')) return

    setStatus('loading')
    setTimeout(() => {
      setStatus('success')
      setTokenInfo({
        hash: '0x' + Array.from({length: 16}, () => Math.floor(Math.random()*16).toString(16)).join('').toUpperCase(),
        slot: 'SLOT #' + Math.floor(100 + Math.random() * 900)
      })
    }, 700)
  }

  if (status === 'success') {
    return (
      <div className="w-full max-w-2xl mx-auto p-4 sm:p-5 rounded-2xl bg-white/[0.03] border border-white/15 text-center flex flex-col items-center gap-2.5">
        <div className="flex items-center gap-2 text-white font-mono text-xs uppercase tracking-widest">
          <ShieldCheck className="w-4 h-4 text-white" />
          <span>ACCESS GRANTED • {tokenInfo?.slot}</span>
        </div>
        <p className="font-mono text-xs text-silver-300">
          OPERATOR KEY: <strong className="text-white font-bold">{tokenInfo?.hash}</strong>
        </p>
        <p className="font-mono text-[10px] text-silver-500 uppercase tracking-wider">
          RUN <code className="text-white bg-white/10 px-1 py-0.5 rounded">npx -y cybermes-mcp install</code> IN YOUR TERMINAL
        </p>
      </div>
    )
  }

  return (
    <div className="w-full max-w-2xl mx-auto" id="beta">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-2 p-2 rounded-2xl bg-white/[0.02] border border-white/10 backdrop-blur-xl">
        <input
          type="email"
          required
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="Enter your work email"
          className="w-full bg-transparent px-4 py-3 font-mono text-xs sm:text-sm text-white placeholder:text-silver-600 focus:outline-none tracking-wide"
        />
        <button
          type="submit"
          disabled={status === 'loading'}
          className="silver-btn w-full sm:w-auto px-7 py-3.5 rounded-xl text-xs font-mono font-bold tracking-[0.25em] uppercase text-black flex items-center justify-center whitespace-nowrap cursor-pointer hover:opacity-95 transition-all flex-shrink-0"
        >
          {status === 'loading' ? 'CHECKING...' : 'JOIN BETA'}
        </button>
      </form>
    </div>
  )
}
